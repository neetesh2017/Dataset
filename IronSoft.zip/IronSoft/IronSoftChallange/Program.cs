﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace IronSoftChallange
{
    class Program
    {
        static void Main(string[] args)
        {

            pushinput();
        }


        static void pushinput()
        {
            Console.WriteLine("Please enter the Mobilekey input: ");
            string input = Console.ReadLine();

            if (String.IsNullOrEmpty(input))
            {
                Console.WriteLine("Input is null");
                return;
            }
            string text = IronSoftChallenge.MobileKey.OldPhonePad(input);
            Console.WriteLine(text);
            Console.WriteLine("Press S to Continue: ");
            string confirm = Console.ReadLine();
            if(String.IsNullOrEmpty(confirm))
            {
                Console.WriteLine("Input is null");
                return;
            }
            if (confirm.Trim().ToUpper() == "S")
            {
                pushinput();
            }
            else
            {
                return;
            }
        }


    }
}
